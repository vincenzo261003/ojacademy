import React from 'react';
import { LayoutPage } from '../../layout/LayoutHoc';

const Home = () => {
    return (
        <>
        <h1>
            Ciao Home
        </h1>
        </>
    );
}

const LayoutHome = LayoutPage(Home);

export default LayoutHome;