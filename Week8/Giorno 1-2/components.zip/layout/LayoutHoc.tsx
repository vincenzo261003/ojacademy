import React, { ReactNode } from 'react';
import { Navbar } from '../components/shared/Navbar';

const LayoutHoc = (PassedComponent : () => JSX.Element ) => {

    const LayoutPage = () => {
        return (
            <>
                <Navbar />
                <PassedComponent />
            </>
        );
    }

    return LayoutPage;
}

export {LayoutHoc as LayoutPage}
